const cv  = document.getElementById("cv");
const ctx = cv.getContext("2d");

function resize() { cv.width = cv.offsetWidth; cv.height = cv.offsetHeight; }
resize();
window.addEventListener("resize", resize);

const buf = [];
const MAX = 1000;

new EventSource("/stream").onmessage = e => {
  buf.push(...JSON.parse(e.data));
  if (buf.length > MAX) buf.splice(0, buf.length - MAX);
};

function draw() {
  const W = cv.width, H = cv.height;
  ctx.fillStyle = "#0a0a0a";
  ctx.fillRect(0, 0, W, H);

  if (buf.length < 2) { requestAnimationFrame(draw); return; }

  ctx.strokeStyle = "#00ff88";
  ctx.lineWidth   = 1.5;
  ctx.beginPath();
  for (let i = 0; i < buf.length; i++) {
    const x = (i / (buf.length - 1)) * W;
    const y = H/2 - buf[i] * (H/2 * 0.8);
    i === 0 ? ctx.moveTo(x, y) : ctx.lineTo(x, y);
  }
  ctx.stroke();
  requestAnimationFrame(draw);
}
draw();
